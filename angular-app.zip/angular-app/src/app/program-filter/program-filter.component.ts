import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-program-filter',
  templateUrl: './program-filter.component.html',
  styleUrls: ['./program-filter.component.css']
})
export class ProgramFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
