import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leftnavmenu',
  templateUrl: './leftnavmenu.component.html',
  styleUrls: ['./leftnavmenu.component.css']
})
export class LeftnavmenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
