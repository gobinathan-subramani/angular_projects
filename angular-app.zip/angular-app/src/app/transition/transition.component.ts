import { Component, OnInit } from '@angular/core';
import { Car } from './car';
import { Activity } from './activity';
import { CarService } from '../shared/carservice';
import { ActivityService } from '../shared/activityService';
import {SelectItem} from './common/selectitem';
import {MessageService} from './common/messageservice';



@Component({
  selector: 'app-transition',
  templateUrl: './transition.component.html',
  styleUrls: ['./transition.component.css']
})
export class TransitionComponent implements OnInit {

  //cars1: Car[];

    cars2: Car[];
    activity: Activity[];
    brands: SelectItem[];

    clonedCars: { [s: string]: Car; } = {};
  messageService: any;

    constructor(private activityService: ActivityService) { }

    ngOnInit() {
        //this.carService.getCarsSmall().then(cars => this.cars1 = cars);
       // this.carService.getCarsSmall().then(cars => this.cars2 = cars);

        this.activityService.getActivity().then(activitys => this.activity = activitys);

        this.brands = [
            {label: 'Audi', value: 'Audi'},
            {label: 'BMW', value: 'BMW'},
            {label: 'Fiat', value: 'Fiat'},
            {label: 'Ford', value: 'Ford'},
            {label: 'Honda', value: 'Honda'},
            {label: 'Jaguar', value: 'Jaguar'},
            {label: 'Mercedes', value: 'Mercedes'},
            {label: 'Renault', value: 'Renault'},
            {label: 'VW', value: 'VW'},
            {label: 'Volvo', value: 'Volvo'}
        ];
    }

    onRowEditInit(car: Car) {
        this.clonedCars[car.vin] = {...car};
    }

    onRowEditSave(car: Car) {
        if (car.year > 0) {
            delete this.clonedCars[car.vin];
            this.messageService.add({severity:'success', summary: 'Success', detail:'Car is updated'});
        }
        else {
            this.messageService.add({severity:'error', summary: 'Error', detail:'Year is required'});
        }
    }

    onRowEditCancel(car: Car, index: number) {
        this.cars2[index] = this.clonedCars[car.vin];
        delete this.clonedCars[car.vin];
    }


    newRow() {
      return {brand: '', year: '', color: '', vin: ''};
    }

}
