export interface Activity {
    id?;
    activity?;
    psd?;
    ph?;
    asd?;
    ah?;
  }
