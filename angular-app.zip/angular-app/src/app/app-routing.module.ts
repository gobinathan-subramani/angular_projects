import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GatechecklistComponent } from './gatechecklist/gatechecklist.component';
import { TransitionComponent } from './transition/transition.component';

const routes: Routes = [
  {path:"", component: GatechecklistComponent},
  {path:"gates", component: GatechecklistComponent},
  {path:"transition", component: TransitionComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
