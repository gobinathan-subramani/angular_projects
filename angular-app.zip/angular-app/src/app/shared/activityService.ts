import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Activity } from '../transition/activity';

@Injectable()
export class ActivityService {

    constructor(private http: HttpClient) {}

    getActivity() {
        return this.http.get<any>('assets/data/activity.json')
            .toPromise()
            .then(res => <Activity[]> res.data)
            .then(data => data);
    }
}
