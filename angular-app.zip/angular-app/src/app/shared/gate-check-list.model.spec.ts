import { GateCheckList } from './gate-check-list.model';

describe('GateCheckList', () => {
  it('should create an instance', () => {
    expect(new GateCheckList()).toBeTruthy();
  });
});
