export class GateCheckList {
    _id :String;
    summary:String;
    createdBy:String;
    raisedDate:Date;
    status:String;
    approver:String;
    closedDate:Date;
    comments:String;
    isException: Boolean
}
