import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GatechecklistComponent } from './gatechecklist/gatechecklist.component';
import { HeaderComponent } from './header/header.component';
import { LeftnavmenuComponent } from './leftnavmenu/leftnavmenu.component';
import { FooterComponent } from './footer/footer.component';
import { ProgramFilterComponent } from './program-filter/program-filter.component';
import { TransitionComponent } from './transition/transition.component';
import { TableModule } from 'primeng/table';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';

import { CarService } from './shared/carservice';

import { AddRowDirective } from './transition/add-row.directive';
import { ActivityService } from './shared/activityService';



@NgModule({
  declarations: [
    AppComponent,
    GatechecklistComponent,
    HeaderComponent,
    LeftnavmenuComponent,
    FooterComponent,
    ProgramFilterComponent,
    TransitionComponent,
    AddRowDirective
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    TableModule,
    InputTextModule,
    ButtonModule,
    DialogModule,
    DropdownModule
  ],
  providers: [CarService,ActivityService],
  bootstrap: [AppComponent]
})
export class AppModule { }
