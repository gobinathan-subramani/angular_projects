import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GatechecklistComponent } from './gatechecklist.component';

describe('GatechecklistComponent', () => {
  let component: GatechecklistComponent;
  let fixture: ComponentFixture<GatechecklistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GatechecklistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GatechecklistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
