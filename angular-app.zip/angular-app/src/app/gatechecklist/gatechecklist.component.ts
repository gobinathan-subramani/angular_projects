import { Component, OnInit } from '@angular/core';

import { NgForm } from '@angular/forms';

import {GateCheckListService} from '../shared/gate-check-list.service';
import {GateCheckList} from '../shared/gate-check-list.model';

@Component({
  selector: 'app-gatechecklist',
  templateUrl: './gatechecklist.component.html',
  styleUrls: ['./gatechecklist.component.css'],
  providers: [GateCheckListService]
})
export class GatechecklistComponent implements OnInit {

  constructor(private gateCheckListService : GateCheckListService) { }

  ngOnInit() {
    this.resetForm();
    this.refreshGateCheckList();
  }

  resetForm(form?: NgForm) {
    if (form)
      form.reset();
    this.gateCheckListService.selectedGateCheckList = {
      _id :"",
      summary:"",
      createdBy:"",
      raisedDate:null,
      status:"",
      approver:"",
      closedDate:null,
      comments:"",
      isException: null
    }
  }

  onSubmit(form: NgForm) {
    if (form.value._id == "") {
      this.gateCheckListService.createGateCheckList(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshGateCheckList();
       });
    }
    else {
      //update logic
      console.log("..2..");
      this.gateCheckListService.updateGateCheckList(form.value).subscribe((res) => {
        console.log("..3..");
        this.resetForm(form);
        this.refreshGateCheckList();
       });
    }
  }

  refreshGateCheckList() {
    this.gateCheckListService.getGateCheckList().subscribe((res) => {
      this.gateCheckListService.gateCheckLists = res as GateCheckList[];
    });
  }


  onEdit(gc: GateCheckList) {
    this.gateCheckListService.selectedGateCheckList = gc;
  }

  onDelete(_id: string, form: NgForm) {
    if (confirm('Are you sure to delete this record ?') == true) {
      this.gateCheckListService.deleteGateCheckList(_id).subscribe((res) => {
        this.refreshGateCheckList();
        this.resetForm(form);
      });
    }
  }

}
